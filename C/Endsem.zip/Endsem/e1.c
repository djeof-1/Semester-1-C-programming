#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int recurse(int **array)
	{
	if(array[0][0]==
	
	}
int main(int argc,char *argv[])
	{
	int a,b,c,e,i,j;
	fscanf("%d",&argv[1]);
	fscanf("%d",&argv[2]);
	a=argv[1];
	b=argv[2];
	c=a*b;
	e=c+2;
	int **f;
	f=(int**)malloc(sizeof(a)*int*);
	for(j=0;j<a;j++)
		{
		f[j]=(int*)malloc(sizeof(b)*int);
		}
	int *d;
	d=(int*)malloc(sizeof(c)*int);
	for(i=3;i<e;i++)
		{
		fscanf("%d",&argv[i]);
		d[i-3]=argv[i];
		}
	
	
	
		
	
